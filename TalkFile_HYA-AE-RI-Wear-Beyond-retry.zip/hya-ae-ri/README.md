# HYA-AE-RI — Wear Beyond.

React + Vite 기반의 정적 업사이클링 스트릿웨어 쇼핑몰 데모입니다.

## 실행
```bash
npm install
npm run dev
```
브라우저에서 Vite가 출력하는 로컬 주소를 엽니다.

## 원본 상품 사진 연결
첨부해 주신 원본 사진 6장을 그대로 `public/products/`에 넣었습니다. 상품 이미지 4장은 앞·뒤 상세 이미지로 연결했고, 모델 착장 사진 2장은 룩북 이미지로 사용합니다. 이미지 파일을 재인코딩하거나 자르거나 보정하지 않았습니다.

- `field-jacket-front.png` / `field-jacket-back.png`
- `tartan-coat-front.jpeg` / `tartan-coat-back.jpeg`
- `lookbook-field-jacket.png` / `lookbook-tartan-coat.jpeg`

상품 이미지는 `object-fit: contain`, 흰색 배경, 이미지 필터/그림자 없음으로 표시합니다.

## 데모 기능
- 카테고리 필터 및 검색
- 상품 상세 모달
- 장바구니 수량 변경 및 삭제
- 브라우저 메모리 상태 기반 모의 주문 완료
- 실제 결제, 서버, 데이터베이스, 회원 계정 없음

새로고침하면 장바구니와 주문 상태가 초기화됩니다.
