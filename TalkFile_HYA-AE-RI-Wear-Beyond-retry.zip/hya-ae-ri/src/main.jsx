import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUpRight, Bag, Check, Menu, Plus, Search, X } from 'lucide-react';
import './styles.css';

const products = [
  { id: '01', name: 'REWORKED FIELD JACKET', category: 'OUTER', price: 128000, note: 'RECONSTRUCTED / LIMITED ARCHIVE', image: '/products/field-jacket-front.png', backImage: '/products/field-jacket-back.png', color: 'MILITARY OLIVE' },
  { id: '02', name: 'ARCHIVE TARTAN WRAP COAT', category: 'OUTER', price: 146000, note: 'RECLAIMED TEXTILE / LIMITED', image: '/products/tartan-coat-front.jpeg', backImage: '/products/tartan-coat-back.jpeg', color: 'TAUPE CHECK' }
];
const money = n => new Intl.NumberFormat('ko-KR').format(n) + ' KRW';

function Wordmark({ small = false }) {
  return <div className={`wordmark ${small ? 'wordmark-small' : ''}`} aria-label="HYA-AE-RI">
    HYA-<span className="ae-mark">AE</span>-RI
  </div>;
}
function ProductImage({ product, className = '' }) {
  const [missing, setMissing] = useState(false);
  return <div className={`product-image ${className}`}>
    {!missing && <img src={product.image} alt={product.name} onError={() => setMissing(true)} />}
    {missing && <div className="image-placeholder"><span className="placeholder-index">HYA—{product.id}</span><span>PRODUCT IMAGE</span><small>ADD YOUR ORIGINAL PHOTO</small></div>}
  </div>;
}
function App() {
  const [cart, setCart] = useState([]);
  const [active, setActive] = useState('ALL');
  const [query, setQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [selected, setSelected] = useState(null);
  const [notice, setNotice] = useState('');
  const [ordered, setOrdered] = useState(false);

  const filtered = useMemo(() => products.filter(p =>
    (active === 'ALL' || p.category === active) &&
    (p.name.toLowerCase().includes(query.toLowerCase()) || p.category.toLowerCase().includes(query.toLowerCase()))
  ), [active, query]);
  const count = cart.reduce((n, item) => n + item.qty, 0);
  const total = cart.reduce((n, item) => n + item.price * item.qty, 0);
  const add = p => {
    setCart(old => old.some(i => i.id === p.id) ? old.map(i => i.id === p.id ? {...i, qty:i.qty+1} : i) : [...old, {...p, qty:1}]);
    setNotice(`${p.name} — ADDED TO BAG`);
    setTimeout(() => setNotice(''), 2200);
  };
  const changeQty = (id, delta) => setCart(old => old.map(i => i.id === id ? {...i, qty:i.qty+delta} : i).filter(i => i.qty > 0));
  const categories = ['ALL', 'OUTER'];

  return <div className="site-shell">
    <aside className="sidebar">
      <a href="#top" className="brand-link"><Wordmark /><span className="brand-tag">Wear Beyond.</span></a>
      <div className="side-rule" />
      <nav className="desktop-nav">
        <a href="#collection">01 / SHOP</a><a href="#story">02 / OUR ARCHIVE</a><a href="#process">03 / RE:WORK</a>
      </nav>
      <div className="sidebar-bottom">
        <span className="vertical-label">DRESS IN YOUR OWN MOOD.</span>
        <div className="side-meta"><span>SEOUL · EST. 2026</span><span>© HYA-AE-RI</span></div>
      </div>
    </aside>

    <main id="top">
      <header className="topbar">
        <button className="icon-btn mobile-menu" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Menu"><Menu size={19}/></button>
        <span className="topbar-note">INDEPENDENT UPCYCLED STREETWEAR</span>
        <div className="top-actions">
          <button className="icon-btn" aria-label="Search" onClick={() => setSearchOpen(!searchOpen)}><Search size={18}/></button>
          <button className="bag-btn" onClick={() => setCartOpen(true)}><Bag size={17}/> BAG <span>({count.toString().padStart(2,'0')})</span></button>
        </div>
      </header>
      {mobileOpen && <div className="mobile-nav"><a href="#collection" onClick={()=>setMobileOpen(false)}>SHOP</a><a href="#story" onClick={()=>setMobileOpen(false)}>OUR ARCHIVE</a><a href="#process" onClick={()=>setMobileOpen(false)}>RE:WORK</a></div>}
      {searchOpen && <div className="search-panel"><Search size={17}/><input autoFocus placeholder="SEARCH THE ARCHIVE" value={query} onChange={e=>setQuery(e.target.value)}/><button onClick={()=>{setQuery('');setSearchOpen(false)}}><X size={17}/></button></div>}

      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span className="olive-dot"/> ARCHIVE Nº 001 — THE RE:MADE COLLECTION</div>
          <h1>Wear <em>Beyond.</em></h1>
          <p className="hero-sub">DRESS IN YOUR OWN MOOD.</p>
          <p className="hero-description">Discarded materials, new perspectives.<br/>Each piece carries a past. Make it yours.</p>
          <a className="text-link" href="#collection">EXPLORE THE COLLECTION <ArrowDown size={14}/></a>
        </div>
        <div className="hero-art hero-lookbook">
          <img src="/products/lookbook-field-jacket.png" alt="HYA-AE-RI field jacket lookbook" />
          <span className="hero-side-note">A DIFFERENT LIFE FOR EVERY THREAD</span>
          <span className="lookbook-caption">LOOKBOOK / 001 — FIELD STUDY</span>
        </div>
        <div className="hero-index">01 <span>/</span> 04</div>
      </section>

      <section className="manifesto" id="story">
        <div className="section-kicker">[ THE HYA-AE-RI POINT OF VIEW ]</div>
        <div className="manifesto-grid">
          <h2>Nothing is<br/> <em>finished.</em></h2>
          <div className="manifesto-text"><p>We see possibility in what already exists. HYA-AE-RI reworks overlooked textiles and forgotten garments into pieces with a new point of view.</p><p>Not mass produced. Not made to blend in. A considered archive of wearable experiments — made to move forward.</p><span className="mono-note">LESS WASTE. MORE CHARACTER. ALWAYS IN PROGRESS.</span></div>
        </div>
      </section>

      <section className="collection" id="collection">
        <div className="collection-heading">
          <div><div className="section-kicker">[ SELECTED REWORKS / 2026 ]</div><h2>The <em>Archive.</em></h2></div>
          <p>ONE-OF-A-KIND FINDS<br/>REWORKED WITH INTENTION.</p>
        </div>
        <div className="shop-toolbar">
          <div className="filters">{categories.map(c=><button key={c} className={active===c?'active':''} onClick={()=>setActive(c)}>{c}</button>)}</div>
          <span className="result-count">SHOWING {filtered.length.toString().padStart(2,'0')} OBJECTS</span>
        </div>
        <div className="product-grid">
          {filtered.map((p, i)=><article className="product-card" key={p.id}>
            <button className="product-open" onClick={()=>setSelected(p)} aria-label={`View ${p.name}`}><ProductImage product={p}/><span className="product-number">HYA—{p.id}</span><span className="quick-view">VIEW OBJECT <ArrowUpRight size={13}/></span></button>
            <div className="product-info"><div><span className="product-category">{p.category} / {p.color}</span><h3>{p.name}</h3></div><span className="price">{money(p.price)}</span></div>
            <div className="product-foot"><span>{p.note}</span><button onClick={()=>add(p)}><Plus size={14}/> ADD</button></div>
          </article>)}
        </div>
        {filtered.length===0 && <div className="empty-state">NO OBJECTS FOUND IN THIS ARCHIVE.</div>}
      </section>

      <section className="process" id="process">
        <div className="process-left"><div className="section-kicker">[ OUR PROCESS ]</div><h2>Re:made.<br/><em>Re:imagined.</em></h2><p>Every material has a history. We keep its traces visible, then give it room to become something else.</p><a href="#collection" className="text-link">FIND YOUR NEXT PIECE <ArrowRight size={14}/></a></div>
        <div className="process-steps"><div><span>01</span><h3>RECOVER</h3><p>We source overlooked garments and leftover textiles.</p></div><div><span>02</span><h3>REWORK</h3><p>We cut, combine and reconstruct with care.</p></div><div><span>03</span><h3>RELEASE</h3><p>Each reworked piece enters the archive in limited numbers.</p></div></div>
      </section>

      <footer><Wordmark small/><span>Wear Beyond.</span><span className="footer-right">DRESS IN YOUR OWN MOOD. <i>© 2026 HYA-AE-RI</i></span></footer>
    </main>

    {notice && <div className="toast"><Check size={15}/>{notice}</div>}
    {cartOpen && <div className="overlay" onMouseDown={e=>e.target===e.currentTarget&&setCartOpen(false)}><aside className="drawer">
      <div className="drawer-head"><div><span className="section-kicker">YOUR SELECTION</span><h2>The Bag <em>({count})</em></h2></div><button className="icon-btn" onClick={()=>setCartOpen(false)}><X/></button></div>
      {ordered ? <div className="order-success"><Check size={30}/><h3>ORDER SIMULATION COMPLETE</h3><p>This is a demo only. No payment has been made.</p><button className="dark-button" onClick={()=>{setOrdered(false);setCart([]);setCartOpen(false)}}>BACK TO ARCHIVE</button></div> :
      cart.length===0 ? <div className="empty-bag">YOUR BAG IS CURRENTLY EMPTY.<br/><a href="#collection" onClick={()=>setCartOpen(false)}>DISCOVER THE ARCHIVE <ArrowRight size={13}/></a></div> :
      <><div className="cart-items">{cart.map(i=><div className="cart-item" key={i.id}><ProductImage product={i}/><div className="cart-item-info"><span>{i.category} / HYA—{i.id}</span><h3>{i.name}</h3><b>{money(i.price)}</b><div className="qty"><button onClick={()=>changeQty(i.id,-1)}>−</button><span>{i.qty}</span><button onClick={()=>changeQty(i.id,1)}>+</button><button className="remove" onClick={()=>changeQty(i.id,-i.qty)}>REMOVE</button></div></div></div>)}</div><div className="cart-total"><div><span>SUBTOTAL</span><b>{money(total)}</b></div><small>Shipping and taxes are not included. Demo checkout only.</small><button className="dark-button" onClick={()=>setOrdered(true)}>PLACE DEMO ORDER <ArrowRight size={15}/></button></div></>}
    </aside></div>}
    {selected && <div className="overlay" onMouseDown={e=>e.target===e.currentTarget&&setSelected(null)}><div className="detail-modal"><button className="modal-close icon-btn" onClick={()=>setSelected(null)}><X/></button><div className="detail-gallery"><ProductImage product={selected} className="detail-image"/><div className="detail-back-image"><img src={selected.backImage} alt={`${selected.name} back view`} /></div></div><div className="detail-copy"><span className="section-kicker">OBJECT Nº {selected.id} / {selected.category}</span><h2>{selected.name}</h2><p>{selected.note}</p><p className="detail-color">COLOR / {selected.color}</p><strong>{money(selected.price)}</strong><button className="dark-button" onClick={()=>{add(selected);setSelected(null);setCartOpen(true)}}>ADD TO BAG <Plus size={15}/></button><small>Each reworked object is unique. Product photography will be supplied from the original archive.</small></div></div></div>}
  </div>;
}
createRoot(document.getElementById('root')).render(<App/>);
